package com.library.admin;

public class Dashboard {
	
	int totalStudent;
	
	int borrowedBook;
	
	int overdueBook;
	
	int totalFine;
	
	
	

}
