package com.library.admin;

public class Fine {
	
	int totalFine;

}
