package com.library.admin;

public class Feedback {
	
	String description;

}
