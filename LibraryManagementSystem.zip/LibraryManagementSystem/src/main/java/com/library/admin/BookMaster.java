package com.library.admin;

public class BookMaster {
	
	int bookMasterId;
	
	int bookTitle;
	
	String author;
	
	String Category;
	
	int isbn;
	
	int quantity;
	
	int price;
	

}
