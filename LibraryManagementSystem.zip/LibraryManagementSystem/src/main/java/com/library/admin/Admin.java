package com.library.admin;

public class Admin {
	

	int noOfStaff;
	
	int availableToday;
	
	int totalExpense;
	
	
	

}
