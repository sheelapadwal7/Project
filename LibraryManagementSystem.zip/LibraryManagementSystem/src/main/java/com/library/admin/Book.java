package com.library.admin;

public class Book {
	
	int bookId;
	
	int isbn;

}
