package com.library.admin;

public class Category {
	
	int standard;

}
