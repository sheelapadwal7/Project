package com.library.inventory;

public class RackManagement {
	
	int rackNo;
	

}
