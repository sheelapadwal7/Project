package com.library.inventory;

import java.util.Date;

public class Requirement {

	int reqId;

	int bookId;

	String title;

	int price;

	String raisedBy;

	int quantity;
	
	String status;

	Date date;

}
