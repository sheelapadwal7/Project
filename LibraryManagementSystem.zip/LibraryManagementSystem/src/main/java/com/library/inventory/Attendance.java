package com.library.inventory;

public class Attendance {
	
	int staffId;
	
	String name;
	
	String status;
	

}
