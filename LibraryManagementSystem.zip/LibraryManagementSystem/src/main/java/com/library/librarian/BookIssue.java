package com.library.librarian;

import java.util.Date;

public class BookIssue {
	
	int studentId;
	
	int bookId;
	
	Date issueDate;
	
	Date returnDate;
	
	String status;
	
	

}
