package com.library.librarian;

public class StudentEnrollment {
	
	int studentId;
	
	String studentname;
	
	String StudentEmail;
	
	String StudentAddress;
	
	String studentContact;

}
