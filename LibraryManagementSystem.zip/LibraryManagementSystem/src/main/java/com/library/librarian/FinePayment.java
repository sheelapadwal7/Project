package com.library.librarian;

import java.util.Date;

public class FinePayment {

	int studentId;
	
	int  fineAmount;
	
	Date paymentDate;
	
	String Remark;
	
}
