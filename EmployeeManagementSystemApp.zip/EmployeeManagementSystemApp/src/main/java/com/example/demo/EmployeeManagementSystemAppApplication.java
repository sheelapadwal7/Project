package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {
    "com.example.demo",
    "com.example.demo.model",
    "com.example.demo.controller",
    "com.example.demo.dto",
    "com.example.demo.repository",
    "com.example.demo.service",
    "com.example.demo.config"
})
public class EmployeeManagementSystemAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementSystemAppApplication.class, args);
    }
}
