package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Attendance;
import com.example.demo.model.Employee;

public interface AttendanceRepository extends JpaRepository<Attendance, Integer> {

	List<Attendance> findByEmployeeAndClockOutTimeIsNull(Employee employee);
    // Additional query methods if needed

	List<Attendance> findByEmployeeId(Integer employeeId);
}
