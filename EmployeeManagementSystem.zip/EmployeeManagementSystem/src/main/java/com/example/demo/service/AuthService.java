package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Login;
import com.example.demo.model.TokenLog;
import com.example.demo.repository.LoginRepository;


@Service
public class AuthService {
	
	
	@Autowired
    private LoginRepository loginRepository;

    // Replace this with your actual authentication logic
	 public boolean authenticate(String username, String password) {
	        // Find the user by username in the database
	        Login login = loginRepository.findByUsername(username);

	        // Check if user exists and the password matches
	        return login != null && login.getPassword().equals(password);
	    }
    public void registerUser(Login login) {
        // Save the user to the database
        loginRepository.save(login);
    }

    public boolean usernameExists(String username) {
        // Check if the username already exists in the database
        return loginRepository.findByUsername(username) != null;
    }

    // Generate token or session for authenticated user
    public String generateToken(int employeeId, String email) {
		String token = UUID.randomUUID().toString();

		// Set token expiry time
		LocalDateTime tokenExpiryTime = LocalDateTime.now().plusMinutes(1);

		// Set logout time
		LocalDateTime logoutTime = LocalDateTime.now().plusMinutes(1);

		// Create TokenLog instance and set properties
		TokenLog tokenLog = new TokenLog();
		tokenLog.setToken(token);
		tokenLog.setValid(true);
		tokenLog.setExpiryTime(tokenExpiryTime);
		tokenLog.setLogoutTime(logoutTime);
		// Set additional properties like student ID, email, purpose, etc.


		return token;
	}
}
