package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Login;

import com.example.demo.service.AuthService;

@RestController
public class AuthController {

    @Autowired
    private AuthService authService;
    
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Login login) {
        // Check if the username already exists
        if (authService.usernameExists(login.getUsername())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username already exists");
        }
        
        // Save the user to the database
        authService.registerUser(login);

        return ResponseEntity.ok().body("User registered successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Login login) {
        // Authenticate user
        boolean isAuthenticated = authService.authenticate(login.getUsername(), login.getPassword());

        if (isAuthenticated) {
            // Generate token or session for authenticated user
            String token = authService.generateToken(0, login.getUsername());

            // Return token in the response along with a success message
            return ResponseEntity.ok().body("Login successful. Token: " + token);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
        }
    }
}

