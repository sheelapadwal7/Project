package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.dto.AttendanceDTO;
import com.example.demo.model.Attendance;
import com.example.demo.model.Employee;
import com.example.demo.repository.AttendanceRepository;
import com.example.demo.repository.EmployeeRepository;

@Service
public class AttendanceService {
    private final AttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;

    public AttendanceService(AttendanceRepository attendanceRepository, EmployeeRepository employeeRepository) {
        this.attendanceRepository = attendanceRepository;
        this.employeeRepository = employeeRepository;
    }

    public void clockIn(Integer employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
            .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        Attendance attendance = new Attendance();
        attendance.setEmployee(employee);
        attendance.setClockInTime(LocalDateTime.now());
        attendanceRepository.save(attendance);
    }

    public void clockOut(Integer employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
            .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        List<Attendance> openAttendances = attendanceRepository.findByEmployeeAndClockOutTimeIsNull(employee);
        if (openAttendances.isEmpty()) {
            throw new IllegalStateException("Employee has not clocked in");
        } else if (openAttendances.size() > 1) {
            // Handle the case where multiple open attendances are found (this should not happen)
            throw new IllegalStateException("Multiple open attendance records found for the employee");
        }

        Attendance attendance = openAttendances.get(0);
        attendance.setClockOutTime(LocalDateTime.now());
        attendanceRepository.save(attendance);
    }


    public List<AttendanceDTO> getAttendanceReport(Integer employeeId) {
        List<Attendance> attendanceList = attendanceRepository.findByEmployeeId(employeeId);
        return attendanceList.stream()
                .map(this::convertToAttendanceDTO)
                .collect(Collectors.toList());
    }

    private AttendanceDTO convertToAttendanceDTO(Attendance attendance) {
        AttendanceDTO attendanceDTO = new AttendanceDTO();
        attendanceDTO.setDate(attendance.getDate());
        attendanceDTO.setClockInTime(attendance.getClockInTime());
        attendanceDTO.setClockOutTime(attendance.getClockOutTime());
        return attendanceDTO;
    }
}


