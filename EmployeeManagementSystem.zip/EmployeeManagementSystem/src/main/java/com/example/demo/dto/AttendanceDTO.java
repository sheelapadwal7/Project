package com.example.demo.dto;


import java.time.LocalDateTime;


public class AttendanceDTO {

    private LocalDateTime date;
    private LocalDateTime clockInTime;
    private LocalDateTime clockOutTime;
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime localDateTime) {
		this.date = localDateTime;
	}
	public LocalDateTime getClockInTime() {
		return clockInTime;
	}
	public void setClockInTime(LocalDateTime localDateTime) {
		this.clockInTime = localDateTime;
	}
	public LocalDateTime getClockOutTime() {
		return clockOutTime;
	}
	public void setClockOutTime(LocalDateTime localDateTime) {
		this.clockOutTime = localDateTime;
	}

    
}

