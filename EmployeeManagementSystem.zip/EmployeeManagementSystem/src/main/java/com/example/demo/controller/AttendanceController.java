package com.example.demo.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.AttendanceDTO;
import com.example.demo.service.AttendanceService;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {
    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @PostMapping("/clock-in/{employeeId}")
    public ResponseEntity<Void> clockIn(@PathVariable Integer employeeId) {
        attendanceService.clockIn(employeeId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/clock-out/{employeeId}")
    public ResponseEntity<Void> clockOut(@PathVariable Integer employeeId) {
        attendanceService.clockOut(employeeId);
        return ResponseEntity.ok().build();
    }
    @GetMapping("/report/{employeeId}")
    public List<AttendanceDTO> getAttendanceReport(@PathVariable Integer employeeId) {
        return attendanceService.getAttendanceReport(employeeId);
    }
}

