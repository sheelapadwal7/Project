package com.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CompanyApplication {

	public static void main(String[] args) {

		FromCompany fc = new FromCompany();
		
		fc.company=new Company();

		fc.company.name = "XYZ corp";
		
		
		Employees emp1 = new Employees();

		emp1.id = 1;

		emp1.name = "Alice";

		emp1.department = "Engineering";

		List<String> skill1 = new ArrayList<>();

		skill1.add("python");

		skill1.add("django");

		skill1.add("javascript");

		emp1.skills = skill1;
		
		
		

		Employees emp2 = new Employees();

		emp2.id = 2;

		emp2.name = "Bob";

		emp2.department = "Marketing";

		//List<String> sk = new ArrayList<>();
		List<String> skill2 = new ArrayList<>();

		skill2.add("Marketing strategy");

		skill2.add("social media");

		skill2.add("Copywriting");

		emp2.skills = skill2;
		
		fc.company.employees=List.of(emp1,emp2);

		Address address = new Address();

		address.street = "123 Main st";

		address.city = "new york";

		address.country = "USA";
		
		fc.company.address= address;
	
		
		
		
		//ToCompany
		

		// Create ToCompany object
		ToCompany tc = new ToCompany();
		tc.setCompany_name(fc.getCompany().getName());

		// Set address
		Address address1 = new Address();
		address1.setStreet(fc.getCompany().getAddress().getStreet());
		address1.setCity(fc.getCompany().getAddress().getCity());
		address1.setCountry(fc.getCompany().getAddress().getCountry());
		tc.setAddress(address1);

		// Set departments and employees
		List<Department> departments = new ArrayList<>();
		Map<String, Department> departmentMap = new HashMap<>();
		for (Employees employee : fc.getCompany().getEmployees()) {
		    Employees toEmployee = new Employees();
		    toEmployee.setId(employee.getId());
		    toEmployee.setName(employee.getName());
		    toEmployee.setSkills(employee.getSkills());

		    if (!departmentMap.containsKey(employee.getDepartment())) {
		        Department department = new Department();
		        department.setDepartmentName(employee.getDepartment());
		        department.setEmployeeDetails(new ArrayList<>());
		        departments.add(department);
		        departmentMap.put(employee.getDepartment(), department);
		    }
		    departmentMap.get(employee.getDepartment()).getEmployeeDetails().add(toEmployee);
		}
		tc.setDepartments(departments);

		// Print the converted ToCompany object
		System.out.println(fc);

		
		System.out.println(tc);
		
		
		
		
	}

}
