package com.test;

import java.util.List;

public class Employees {

	
	int id;
	
	String name;
	
	String department;
	
	List<String> skills;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "Employees [id=" + id + ", name=" + name + ", department=" + department + ", skills=" + skills + "]";
	}
	
}
