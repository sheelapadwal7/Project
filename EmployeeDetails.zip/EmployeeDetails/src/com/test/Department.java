package com.test;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Department {
	
	String departmentName;
	
	List<Employees>  employeeDetails;

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public List<Employees> getEmployeeDetails() {
		return employeeDetails;
	}

	public void setEmployeeDetails(List<Employees> employeeDetails) {
		this.employeeDetails = employeeDetails;
	}

	@Override
	public String toString() {
		return "Department [departmentName=" + departmentName + ", employeeDetails=" + employeeDetails + "]";
	}
	
}
