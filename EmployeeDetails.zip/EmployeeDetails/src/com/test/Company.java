package com.test;

import java.util.List;

public class Company {
	
	public String name;
    public List<Employees> employees;
    public  Address address;
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Employees> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employees> employees) {
		this.employees = employees;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Company [name=" + name + ", employees=" + employees + ", address=" + address + "]";
	}
    
    
	
	

}
