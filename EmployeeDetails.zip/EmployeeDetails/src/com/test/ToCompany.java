package com.test;

import java.util.List;

public class ToCompany {
	
	String company_name;
	
	List<Department> departments;
	
	Address address;

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public List<Department> getDepartments() {
		return departments;
	}

	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "ToCompany [company_name=" + company_name + ", departments=" + departments + ", address=" + address
				+ "]";
	}

	
	
	

	
	

}
