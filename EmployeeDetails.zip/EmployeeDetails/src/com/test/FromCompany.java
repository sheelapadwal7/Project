package com.test;

public class FromCompany {
	
	Company company;

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "FromCompany [company=" + company + "]";
	}

	
	
	

}
